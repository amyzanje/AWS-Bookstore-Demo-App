export const categories = {
  cooks: "Cookbooks",
  database: "Database",
  fairy: "Fairy Tales",
  scifi: "Science Fiction",
  home: "Home Improvement",
  cars: "Cars",
  woodwork: "Woodwork",
}