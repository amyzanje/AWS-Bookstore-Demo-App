export default {
  apiGateway: {
    REGION: "us-east-1",
    API_URL: "https://yuq7ws39pj.execute-api.us-east-1.amazonaws.com/prod",
  },
  cognito: {
    REGION: "us-east-1",
    USER_POOL_ID: "us-east-1_yA0vYd5AL",
    APP_CLIENT_ID: "25048pu470diqqcvdo56i0cat9",
    IDENTITY_POOL_ID: "us-east-1:1ff5a5f9-dd44-4934-b575-97d8d0952439"
  }
};
